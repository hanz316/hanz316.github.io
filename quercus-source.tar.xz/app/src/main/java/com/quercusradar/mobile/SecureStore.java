package com.quercusradar.mobile;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecureStore {
    private static final String KEY_ALIAS = "quercus_radar_local_v1";
    private final SharedPreferences prefs;

    SecureStore(Context context) { prefs = context.getSharedPreferences("radar",Context.MODE_PRIVATE); }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (!ks.containsAlias(KEY_ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            return generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS,null)).getSecretKey();
    }

    void setSecret(String name,String value) throws Exception {
        if (value == null || value.isEmpty()) return;
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] iv = c.getIV(); byte[] all = new byte[iv.length + encrypted.length];
        System.arraycopy(iv,0,all,0,iv.length); System.arraycopy(encrypted,0,all,iv.length,encrypted.length);
        if (!prefs.edit().putString(name,Base64.encodeToString(all,Base64.NO_WRAP)).commit())
            throw new IllegalStateException("本地密钥保存失败");
    }

    String secret(String name) throws Exception {
        String encoded = prefs.getString(name, ""); if(encoded.isEmpty()) return "";
        byte[] all = Base64.decode(encoded,Base64.DEFAULT);
        if(all.length <= 28) throw new IllegalStateException("密钥存储损坏");
        byte[] iv = new byte[12], encrypted = new byte[all.length-12];
        System.arraycopy(all,0,iv,0,12); System.arraycopy(all,12,encrypted,0,encrypted.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
        return new String(c.doFinal(encrypted),StandardCharsets.UTF_8);
    }

    String get(String name,String def) { return prefs.getString(name,def); }
    void put(String name,String value) { prefs.edit().putString(name,value).apply(); }
    boolean enabled() { return prefs.getBoolean("enabled",false); }
    void enabled(boolean v) { prefs.edit().putBoolean("enabled",v).apply(); }
}
