package com.quercusradar.mobile;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.Duration;

final class Schedule {
    static final ZoneId ZONE=ZoneId.of("America/Toronto");
    static final int MORNING=1409,EVENING=1421;
    private Schedule(){}
    static void update(Context context) {
        JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        SecureStore prefs=new SecureStore(context);
        if(!prefs.enabled()){scheduler.cancel(MORNING);scheduler.cancel(EVENING);return;}
        scheduleOne(context,scheduler,MORNING,9,false);
        scheduleOne(context,scheduler,EVENING,21,false);
    }
    static void next(Context context,int jobId) {
        SecureStore prefs=new SecureStore(context);
        if(!prefs.enabled())return;
        JobScheduler scheduler=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        scheduleOne(context,scheduler,jobId,jobId==MORNING?9:21,true);
    }
    private static void scheduleOne(Context context,JobScheduler scheduler,int id,int hour,boolean force) {
        if(!force && scheduler.getPendingJob(id)!=null)return;
        ZonedDateTime now=ZonedDateTime.now(ZONE);
        ZonedDateTime next=now.withHour(hour).withMinute(0).withSecond(0).withNano(0);
        if(!next.isAfter(now))next=next.plusDays(1);
        long millis=Math.max(1000,Duration.between(now,next).toMillis());
        JobInfo request=new JobInfo.Builder(id,new ComponentName(context,ScanJob.class))
                .setMinimumLatency(millis)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setBackoffCriteria(30*60*1000,JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .build();
        if(scheduler.schedule(request)!=JobScheduler.RESULT_SUCCESS)
            prefs.put("lastError","计划任务注册失败，JobScheduler 拒绝请求");
    }
}
