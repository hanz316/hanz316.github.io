package com.quercusradar.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.time.ZonedDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class MainActivity extends Activity {
    private SecureStore prefs;
    private TextView status,report;
    private EditText token,password;
    private CheckBox enable;
    private final ExecutorService workers=Executors.newSingleThreadExecutor();
    private static final int BG=Color.rgb(17,20,27), FG=Color.rgb(239,241,245), MUTED=Color.rgb(162,171,185);
    private static final int ACCENT=Color.rgb(79,124,242);
    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=new SecureStore(this);build();Schedule.update(this);}
    private TextView text(String content,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(content);t.setTextSize(size);t.setTextColor(color);
        t.setPadding(0,12,0,12);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private Button button(String label,LinearLayout root,Runnable fn){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(15);
        b.setTextColor(FG);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=12;root.addView(b,p);b.setOnClickListener(v->fn.run());return b;
    }
    private EditText edit(LinearLayout root,String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(FG);e.setHintTextColor(MUTED);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(MUTED));e.setHint(hint);
        root.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;
    }
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,32,32,46);
        scroll.addView(root);setContentView(scroll);
        root.addView(text("Quercus 学业雷达",27,FG,true));
        root.addView(text("所有课程 · 公告 · 作业 · 文件变更",14,MUTED,false));
        root.addView(text("隐私：凭据由 Android Keystore 加密，仅保存在手机；永不上传到 ChatGPT。",12,MUTED,false));
        root.addView(text("QUERCUS API TOKEN",13,FG,true));
        token=edit(root,"输入 Quercus Token（留空则保持原值）");
        token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(text("GMAIL APP PASSWORD",13,FG,true));
        password=edit(root,"Gmail 16 位应用专用密码（留空保持原值）");
        password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(text("收件人与发件人固定：hanz060316@gmail.com",12,MUTED,false));
        button("保存加密凭据",root,()->{
            try {
                prefs.setSecret("quercus_token",token.getText().toString().trim());
                prefs.setSecret("gmail_password",password.getText().toString().trim());
                token.setText("");password.setText("");refresh("凭据已保存在设备本地");
            } catch(Exception ex) {refresh("保存失败："+ex.getMessage());}
        });
        enable=new CheckBox(this);enable.setText("启用每天多伦多时间 09:00 和 21:00 后台扫描+自动邮件");
        enable.setTextColor(FG);enable.setChecked(prefs.enabled());
        LinearLayout.LayoutParams check=new LinearLayout.LayoutParams(-1,-2);check.topMargin=18;root.addView(enable,check);
        enable.setOnCheckedChangeListener((v,isChecked)->{prefs.enabled(isChecked);Schedule.update(this);refresh(isChecked?"已请求系统注册后台任务（可能因省电机制延迟）":"已取消后台任务");});
        status=text("",13,MUTED,false);root.addView(status);
        button("立即扫描全部课程（不发信）",root,()->runAsync(false));
        button("扫描并测试发邮件",root,()->runAsync(true));
        button("分享最近报告到 ChatGPT（手动确认）",root,()->{
            String content=prefs.get("lastReport","");
            if(content.isEmpty()){refresh("尚无报告，先执行扫描");return;}
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,content);
            startActivity(Intent.createChooser(share,"选择 ChatGPT 并手动发送"));
        });
        root.addView(text("最近报告",19,FG,true));
        report=text("",13,FG,false);report.setTextIsSelectable(true);root.addView(report);
        root.addView(text("重要限制：Android 省电/Doze 会推迟后台运行。邮件由手机直接发出，不通过普通 ChatGPT 聊天。当前版本扫描所有可访问文件的元信息；只提取部分小型 TXT、HTML、DOCX 和 PPTX 正文。PDF、视频及不可访问文件不会假装已经阅读。",12,MUTED,false));
        refresh("");
    }
    private void refresh(String msg){
        String success=prefs.get("lastSuccess","无");
        String failure=prefs.get("lastError","");
        boolean hasToken=!prefs.get("quercus_token","").isEmpty();
        boolean hasGmail=!prefs.get("gmail_password","").isEmpty();
        status.setText((msg.isEmpty()?"":msg+"\n")+
                "Quercus 密钥："+(hasToken?"已保存":"未设置")+" ｜ Gmail 授权："+(hasGmail?"已保存":"未设置")+
                "\n定时任务："+(prefs.enabled()?"已请求系统注册":"已关闭")+
                "\n上次成功邮件："+success+(failure.isEmpty()?"":"\n最近错误："+failure));
        report.setText(prefs.get("lastReport","尚无报告"));
    }
    private void runAsync(boolean send){
        status.setText("正在扫描 Quercus，请勿重复点击…");
        workers.execute(()->{
            String resultMsg;
            try {
                String key=prefs.secret("quercus_token");
                if(key.isEmpty())throw new IllegalStateException("请先保存 Quercus Token");
                RadarScanner.Result result=new RadarScanner(getApplicationContext(),key).scan();
                if(send){
                    String pwd=prefs.secret("gmail_password");
                    if(pwd.isEmpty())throw new IllegalStateException("请先保存 Gmail 应用专用密码");
                    GmailSmtp.send(pwd,"Quercus 学业雷达｜手动测试",result.report);
                    prefs.put("fp",result.fingerprints);
                    prefs.put("lastSuccess",ZonedDateTime.now(Schedule.ZONE).toString());
                }
                prefs.put("lastReport",result.report);prefs.put("lastError","");
                resultMsg=send?"Quercus 已扫描，邮件服务器已接受测试邮件":"扫描成功；报告仅保存在本机，未自动发邮件";
            }catch(Exception ex){resultMsg="执行失败："+ex.getClass().getSimpleName()+"："+ex.getMessage();prefs.put("lastError",resultMsg);}
            String finalResultMsg=resultMsg;runOnUiThread(()->refresh(finalResultMsg));
        });
    }
    @Override protected void onDestroy(){super.onDestroy();workers.shutdown();}
}
