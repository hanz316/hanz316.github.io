package com.quercusradar.mobile;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class ScanJob extends JobService {
    private volatile Thread running;
    @Override public boolean onStartJob(final JobParameters params) {
        final int jobId=params.getJobId();
        if(jobId!=Schedule.MORNING && jobId!=Schedule.EVENING){jobFinished(params,false);return false;}
        // 当前 Job 不能在运行中以同一 ID 重新安排，否则 Android 会停止运行中的 Job。
        running=new Thread(()->{
            SecureStore storage=new SecureStore(getApplicationContext());
            try {
                if(!storage.enabled())return;
                String slot=jobId==Schedule.MORNING?"09":"21";
                String today=ZonedDateTime.now(Schedule.ZONE).format(DateTimeFormatter.ofPattern("yyyy-MM-dd",Locale.US));
                String key=today+":"+slot;
                if(key.equals(storage.get("lastSentKey","")))return;
                String token=storage.secret("quercus_token");
                String pass=storage.secret("gmail_password");
                if(token.isEmpty()||pass.isEmpty())throw new IllegalStateException("需要先在 App 设置 Quercus Token 和 Gmail 应用专用密码");
                RadarScanner.Result result=new RadarScanner(getApplicationContext(),token).scan();
                String subject="Quercus 学业简报｜"+today+" "+(jobId==Schedule.MORNING?"早间":"晚间");
                GmailSmtp.send(pass,subject,result.report);
                storage.put("lastSentKey",key);
                storage.put("fp",result.fingerprints);
                storage.put("lastReport",result.report);
                storage.put("lastSuccess",ZonedDateTime.now(Schedule.ZONE).toString());
                storage.put("lastError","");
            }catch(Exception ex){storage.put("lastError",ex.getClass().getSimpleName()+"："+ex.getMessage());}
            finally {new Handler(Looper.getMainLooper()).post(()->{jobFinished(params,false);Schedule.next(this,jobId);});}
        },"QuercusBackgroundScan");
        running.start();return true;
    }
    @Override public boolean onStopJob(JobParameters params){
        if(running!=null)running.interrupt();
        return true;
    }
}
