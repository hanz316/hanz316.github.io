package com.quercusradar.mobile;

import android.content.Context;
import android.text.format.DateFormat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;

final class RadarScanner {
    private static final ZoneId TORONTO = ZoneId.of("America/Toronto");
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z",Locale.US);
    private final CanvasApi api;
    private final SecureStore store;
    private final JSONObject before;
    private final JSONObject after;
    private final List<Due> tasks = new ArrayList<>();
    private final List<String> changes = new ArrayList<>();
    private final List<String> errors = new ArrayList<>();
    private int courseCount=0, fileCount=0, announcementCount=0, bodyRead=0, bodySkipped=0, pagesRead=0;

    static final class Result {
        final String report;final String fingerprints;
        Result(String report,String fingerprints){this.report=report;this.fingerprints=fingerprints;}
    }
    static final class Due {
        String title, course, kind, link, detail; long instant;
        Due(String c,String t,String k,String url,String d,long when){course=c;title=t;kind=k;link=url;detail=d;instant=when;}
    }
    RadarScanner(Context ctx,String token) throws Exception {
        api=new CanvasApi(token);store=new SecureStore(ctx);
        JSONObject b;
        try{b=new JSONObject(store.get("fp","{}"));}catch(Exception e){b=new JSONObject();}
        before=b;after=new JSONObject(b.toString());
    }
    private static String hash(String input) {
        try {byte[] digest=MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder s=new StringBuilder();for(byte b:digest)s.append(String.format(Locale.US,"%02x",b&0xff));return s.toString();
        }catch(Exception e){return input.substring(0,Math.min(input.length(),64));}
    }
    private static String iso(String date) {
        if(date==null||date.trim().isEmpty()||date.equals("null"))return "";
        try{return Instant.parse(date).atZone(TORONTO).format(FORMAT);}catch(Exception e){return date;}
    }
    private static long epoch(String date) {
        try{return Instant.parse(date).toEpochMilli();}catch(Exception e){return -1;}
    }
    private static String field(JSONObject o,String key){return o.optString(key,"").equals("null")?"":o.optString(key,"");}
    private static String link(JSONObject o) {return field(o,"html_url");}
    private void mark(String id,String details,String desc) {
        String h=hash(details);
        if (!h.equals(before.optString(id,""))) {
            if(changes.size()<80)changes.add(desc);
        }
        try{after.put(id,h);}catch(Exception ignored){}
    }
    private JSONArray safeList(String course,String name,String path) {
        try{return api.list(path);}catch(Exception e){errors.add(course+" · "+name+": "+e.getMessage());return new JSONArray();}
    }
    private JSONObject safeObject(String course,String name,String path) {
        try{return api.object(path);}catch(Exception e){errors.add(course+" · "+name+": "+e.getMessage());return new JSONObject();}
    }
    private void dueItem(String course,String kind,JSONObject o,String title,String when,String id,String detail) {
        long millis=epoch(when);
        long now=System.currentTimeMillis();
        if(millis<0||millis<now-3L*86400000||millis>now+14L*86400000)return;
        tasks.add(new Due(course,title,kind,link(o),CanvasApi.clip(detail,180),millis));
    }
    Result scan() throws Exception {
        JSONArray courses = api.list("/api/v1/courses?enrollment_state=active&per_page=100");
        if(courses.length()==0)errors.add("API 返回 0 门活跃课程，可能是课程权限或注册状态问题");
        for(int ci=0;ci<courses.length();ci++) {
            JSONObject c=courses.optJSONObject(ci);if(c==null)continue;
            String id=String.valueOf(c.optLong("id",0));if(id.equals("0"))continue;
            String course=field(c,"course_code");if(course.isEmpty())course=field(c,"name");
            if(course.isEmpty())course="课程 "+id;
            courseCount++;
            String root="/api/v1/courses/"+id;
            try {
                JSONArray assignments=safeList(course,"Assignments",root+"/assignments?include%5B%5D=overrides&per_page=100");
                for(int i=0;i<assignments.length();i++){
                    JSONObject a=assignments.optJSONObject(i);if(a==null||a.optBoolean("locked_for_user",false))continue;
                    String title=field(a,"name"), due=field(a,"due_at");
                    String details=CanvasApi.strip(field(a,"description"));
                    mark("a:"+id+":"+a.optLong("id"),title+"|"+due+"|"+details+"|"+field(a,"unlock_at")+"|"+field(a,"lock_at"),
                            "[作业] "+course+" · "+title+(due.isEmpty()?"":" · 截止 "+iso(due)));
                    dueItem(course,"作业",a,title,due,id,details);
                    JSONArray overrides=a.optJSONArray("overrides");
                    if(overrides!=null && overrides.length()>0)errors.add(course+" · "+title+": 存在分组/个人 override，默认截止时间不一定适用于你，请核对原链接");
                }
            }catch(Exception e){errors.add(course+" assignments: "+e.getMessage());}
            try{
                JSONArray quizzes=safeList(course,"Quizzes",root+"/quizzes?per_page=100");
                for(int i=0;i<quizzes.length();i++){
                    JSONObject q=quizzes.optJSONObject(i);if(q==null)continue;
                    String title=field(q,"title"),due=field(q,"due_at"),desc=CanvasApi.strip(field(q,"description"));
                    mark("q:"+id+":"+q.optLong("id"),title+"|"+due+"|"+desc,"[测验] "+course+" · "+title+(due.isEmpty()?"":" · 截止 "+iso(due)));
                    dueItem(course,"测验",q,title,due,id,desc);
                }
            }catch(Exception e){errors.add(course+" quizzes: "+e.getMessage());}
            try {
                JSONArray announcements=safeList(course,"Announcements",root+"/discussion_topics?only_announcements=true&per_page=100");
                for(int i=0;i<announcements.length();i++) {
                    JSONObject a=announcements.optJSONObject(i);if(a==null)continue;announcementCount++;
                    String title=field(a,"title"),msg=CanvasApi.strip(field(a,"message"));
                    mark("n:"+id+":"+a.optLong("id"),title+"|"+msg+"|"+field(a,"updated_at"),
                            "[公告] "+course+" · "+title+"："+CanvasApi.clip(msg,300)+" "+link(a));
                }
            }catch(Exception e){errors.add(course+" announcements: "+e.getMessage());}
            try {
                JSONArray modules=safeList(course,"Modules",root+"/modules?include%5B%5D=items&per_page=100");
                for(int i=0;i<modules.length();i++) {
                    JSONObject module=modules.optJSONObject(i);if(module==null)continue;
                    String mod=field(module,"name");
                    JSONArray items=module.optJSONArray("items");
                    if(items!=null)for(int j=0;j<items.length();j++) {
                        JSONObject item=items.optJSONObject(j);if(item==null)continue;
                        String name=field(item,"title"),type=field(item,"type");
                        mark("m:"+id+":"+module.optLong("id")+":"+item.optLong("id"),name+"|"+type+"|"+field(item,"html_url"),
                                "[模块] "+course+" · "+mod+" · "+name+" ("+type+")");
                    }
                }
            }catch(Exception e){errors.add(course+" modules: "+e.getMessage());}
            try{
                JSONArray pages=safeList(course,"Pages",root+"/pages?per_page=100");
                for(int i=0;i<pages.length();i++){
                    JSONObject p=pages.optJSONObject(i);if(p==null)continue;
                    String pageId=field(p,"url"),title=field(p,"title"),modified=field(p,"updated_at");
                    String pageKey="p:"+id+":"+pageId;
                    if(!hash(title+"|"+modified).equals(before.optString(pageKey,"")) && pagesRead<10){
                        JSONObject page=safeObject(course,"Page "+title,root+"/pages/"+CanvasApi.encode(pageId));
                        String text=CanvasApi.strip(field(page,"body"));
                        mark(pageKey,title+"|"+modified,"[页面] "+course+" · "+title+": "+CanvasApi.clip(text,200));pagesRead++;
                    }else mark(pageKey,title+"|"+modified,"[页面] "+course+" · "+title);
                }
            }catch(Exception e){errors.add(course+" pages: "+e.getMessage());}
            try {
                JSONArray files=safeList(course,"Files",root+"/files?per_page=100");
                for(int i=0;i<files.length();i++){
                    JSONObject f=files.optJSONObject(i);if(f==null)continue;fileCount++;
                    String fileId="f:"+id+":"+f.optLong("id"),name=field(f,"display_name"),changed=field(f,"updated_at");
                    if(name.isEmpty())name=field(f,"filename");
                    String description=CanvasApi.strip(field(f,"description"));
                    String footprint=name+"|"+changed+"|"+f.optLong("size")+"|"+description;
                    boolean changedFile=!hash(footprint).equals(before.optString(fileId,""));
                    if(changedFile) {
                        String content="";
                        if(bodyRead<12 && f.optLong("size",0)>0 && f.optLong("size",0)<750000) {
                            String filename=name.toLowerCase(Locale.US);
                            if(filename.endsWith(".txt")||filename.endsWith(".md")||filename.endsWith(".csv")||filename.endsWith(".html")||filename.endsWith(".docx")||filename.endsWith(".pptx")) {
                                try {content=readFileText(field(f,"url"),filename);bodyRead++;}
                                catch(Exception e){bodySkipped++;errors.add(course+" · 文件正文未读取: "+name+" ("+e.getMessage()+")");}
                            } else bodySkipped++;
                        } else bodySkipped++;
                        mark(fileId,footprint,"[文件] "+course+" · "+name+" · 更新 "+iso(changed)+
                                (description.isEmpty()?"":" · "+CanvasApi.clip(description,100))+
                                (content.isEmpty()?" · 正文未提取":" · 正文摘录："+CanvasApi.clip(content,200)));
                    }else mark(fileId,footprint,"[文件] "+course+" · "+name);
                }
            }catch(Exception e){errors.add(course+" files: "+e.getMessage());}
            try {
                JSONArray events=safeList(course,"Calendar", "/api/v1/calendar_events?type=event&context_codes%5B%5D=course_"+id+"&per_page=100");
                for(int i=0;i<events.length();i++) {
                    JSONObject ev=events.optJSONObject(i);if(ev==null)continue;
                    String title=field(ev,"title"), start=field(ev,"start_at");
                    mark("e:"+id+":"+ev.optLong("id"),title+"|"+start+"|"+field(ev,"description"),
                            "[日历] "+course+" · "+title+" · "+iso(start));
                    dueItem(course,"日历事项",ev,title,start,id,CanvasApi.strip(field(ev,"description")));
                }
            }catch(Exception e){errors.add(course+" calendar: "+e.getMessage());}
        }
        return new Result(createReport(),after.toString());
    }
    private static String readFileText(String uri,String filename) throws Exception {
        if(uri==null||uri.isEmpty())throw new IllegalArgumentException("没有下载链接");
        URL url=new URL(uri);
        if(!"https".equalsIgnoreCase(url.getProtocol()))throw new IllegalArgumentException("非 HTTPS 文件地址");
        // 文件下载不可附带 Quercus Bearer Token；遵循授权服务返回的文件 URL，限制重定向。
        for(int hops=0;hops<3;hops++) {
            HttpURLConnection c=(HttpURLConnection)url.openConnection();
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(12000);
            try {
                int code=c.getResponseCode();
                if(code>=300 && code<=308 && c.getHeaderField("Location")!=null) {
                    URL next=new URL(url,c.getHeaderField("Location"));
                    if(!"https".equalsIgnoreCase(next.getProtocol()))throw new IllegalArgumentException("拒绝非 HTTPS 重定向");
                    url=next;continue;
                }
                if(code!=200)throw new IllegalStateException("文件 HTTP "+code);
                try(InputStream stream=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[8192];int n;while((n=stream.read(buf))!=-1){if(out.size()+n>850000)throw new IllegalStateException("文件内容超过限制");out.write(buf,0,n);}
                    byte[] data=out.toByteArray();
                    if(filename.endsWith(".docx")||filename.endsWith(".pptx")) {
                        StringBuilder text=new StringBuilder();
                        try(ZipInputStream zip=new ZipInputStream(new java.io.ByteArrayInputStream(data))) {
                            ZipEntry entry;
                            while((entry=zip.getNextEntry())!=null) {
                                String path=entry.getName();
                                if((filename.endsWith(".docx") && path.equals("word/document.xml")) ||
                                        (filename.endsWith(".pptx") && path.matches("ppt/slides/slide[0-9]+\\.xml"))) {
                                    ByteArrayOutputStream xml=new ByteArrayOutputStream();while((n=zip.read(buf))!=-1){if(xml.size()+n>400000)break;xml.write(buf,0,n);}
                                    text.append(CanvasApi.strip(xml.toString("UTF-8"))).append(" ");
                                }
                            }
                        }
                        return CanvasApi.clip(text.toString(),1200);
                    }
                    return CanvasApi.clip(CanvasApi.strip(new String(data,StandardCharsets.UTF_8)),1200);
                }
            }finally{c.disconnect();}
        }
        throw new IllegalStateException("文件重定向过多");
    }
    private String createReport() {
        Collections.sort(tasks,Comparator.comparingLong(d->d.instant));
        String now=ZonedDateTime.now(TORONTO).format(FORMAT);
        StringBuilder r=new StringBuilder("Quercus 学业雷达 · 扫描报告\n");
        r.append("扫描时间：").append(now).append("\n");
        r.append("时区：America/Toronto（自动处理夏令时）\n");
        r.append("覆盖：").append(courseCount).append(" 门活跃课程；").append(fileCount).append(" 个文件元数据；")
                .append(announcementCount).append(" 条公告；新/变更文件中提取正文 ").append(bodyRead).append(" 项\n");
        r.append("说明：这不是对所有 PDF、视频、受限资料的全文扫描；部分课程存在个人截止日期，需以 Quercus 页面为准。\n\n");
        r.append("【未来14天到期/近3天逾期】\n");
        if(tasks.isEmpty())r.append("未发现具有明确日期的事项（不代表没有作业）。\n");
        for(int i=0;i<Math.min(tasks.size(),35);i++){
            Due d=tasks.get(i);r.append(i+1).append(". ").append(d.course).append(" · ").append(d.kind).append("：").append(d.title)
                    .append("\n   时间：").append(Instant.ofEpochMilli(d.instant).atZone(TORONTO).format(FORMAT));
            if(!d.detail.isEmpty())r.append("\n   要求摘录：").append(d.detail);
            if(!d.link.isEmpty())r.append("\n   链接：").append(d.link);
            r.append("\n");
        }
        if(tasks.size()>35)r.append("另有 ").append(tasks.size()-35).append(" 项，界面未逐项展示，请查看 Quercus。\n");
        r.append("\n【自上次成功邮件后的新增或变化】\n");
        if(changes.isEmpty())r.append("未发现元信息变化。\n");
        for(int i=0;i<Math.min(changes.size(),30);i++)r.append(i+1).append(". ").append(changes.get(i)).append("\n");
        if(changes.size()>30)r.append("其余变化 ").append(changes.size()-30).append(" 项已省略。\n");
        if(!errors.isEmpty()){
            r.append("\n【无法读取／需要核对（共 ").append(errors.size()).append(" 项）】\n");
            for(int i=0;i<Math.min(errors.size(),20);i++)r.append("- ").append(errors.get(i)).append("\n");
        }
        if(bodySkipped>0)r.append("\n提示：本轮 ").append(bodySkipped).append(" 个更新文件未完成正文提取（类型/大小/数量限制）。\n");
        r.append("\n该报告由手机独立生成并发送，未传输到普通 ChatGPT 聊天。\n");
        return r.toString();
    }
}
