package com.quercusradar.mobile;

import android.util.Base64;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.net.Socket;
import java.util.Locale;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

final class GmailSmtp {
    private static final String MAIL="hanz060316@gmail.com";
    private static final int PORT=465;
    private static final String HOST="smtp.gmail.com";
    private final BufferedReader in;
    private final BufferedWriter out;
    private GmailSmtp(BufferedReader in,BufferedWriter out){this.in=in;this.out=out;}
    private int reply() throws Exception {
        String line;String last="";
        int num=0;
        for(int i=0;i<40;i++){
            line=in.readLine();if(line==null)throw new IllegalStateException("SMTP 连接已断开");
            last=line;
            if(line.length()<3)throw new IllegalStateException("SMTP 返回无效");
            num=Integer.parseInt(line.substring(0,3));
            if(line.length()<=3||line.charAt(3)!='-')break;
        }
        if(num>=400)throw new IllegalStateException("SMTP 发送失败，响应代码 "+num); // 绝不打印服务器响应中的隐私信息
        return num;
    }
    private int cmd(String command) throws Exception {out.write(command+"\r\n");out.flush();return reply();}
    private static String b64(String s){return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}
    private void expect(String cmd,int expected) throws Exception {
        int status=cmd(cmd);if(status!=expected)throw new IllegalStateException("SMTP 状态异常 "+status+"（预期 "+expected+"）");
    }
    static void send(String appPassword,String subject,String text) throws Exception {
        if(appPassword==null||appPassword.trim().isEmpty())throw new IllegalStateException("未配置 Gmail 应用专用密码");
        SSLSocket socket=(SSLSocket)SSLSocketFactory.getDefault().createSocket(HOST,PORT);
        socket.setSoTimeout(18000);
        javax.net.ssl.SSLParameters sslParams = socket.getSSLParameters();
        sslParams.setEndpointIdentificationAlgorithm("HTTPS");
        socket.setSSLParameters(sslParams);
        try {
            socket.startHandshake();
            GmailSmtp smtp=new GmailSmtp(new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8)),
                    new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.US_ASCII)));
            if(smtp.reply()!=220)throw new IllegalStateException("SMTP 握手失败");
            smtp.expect("EHLO quercus-radar.local",250);
            smtp.expect("AUTH LOGIN",334);
            smtp.expect(b64(MAIL),334);
            smtp.expect(b64(appPassword.replace(" ","")),235);
            smtp.expect("MAIL FROM:<"+MAIL+">",250);
            smtp.expect("RCPT TO:<"+MAIL+">",250);
            smtp.expect("DATA",354);
            String safeSubject=Base64.encodeToString(subject.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
            String body=Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
            String mime="From: <"+MAIL+">\r\n"+"To: <"+MAIL+">\r\n"
                    +"Subject: =?UTF-8?B?"+safeSubject+"?=\r\n"
                    +"MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
            smtp.out.write(mime);
            for(int i=0;i<body.length();i+=76)smtp.out.write(body.substring(i,Math.min(i+76,body.length()))+"\r\n");
            smtp.out.write("\r\n.\r\n");smtp.out.flush();
            if(smtp.reply()!=250)throw new IllegalStateException("邮箱未确认接收邮件");
            try {smtp.cmd("QUIT");}catch(Exception ignored){}
        }finally{socket.close();}
    }
}
