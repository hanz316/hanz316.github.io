package com.quercusradar.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class CanvasApi {
    private static final String ORIGIN = "https://q.utoronto.ca";
    private final String token;
    CanvasApi(String token) { this.token = token.trim(); }
    static String encode(String v) { try{return URLEncoder.encode(v,"UTF-8");}catch(Exception e){throw new RuntimeException(e);} }

    private static void trusted(URL url) throws Exception {
        if (!url.getProtocol().equalsIgnoreCase("https") || !url.getHost().equalsIgnoreCase("q.utoronto.ca") || url.getPort()!=-1)
            throw new SecurityException("拒绝非 Quercus API 域名");
        if(!url.getPath().startsWith("/api/v1/")) throw new SecurityException("拒绝非 API 路径");
    }
    static String strip(String html) {
        if(html==null) return "";
        String v = html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>"," ")
                .replaceAll("(?is)<[^>]+>"," ")
                .replace("&nbsp;"," ").replace("&amp;","&")
                .replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"");
        return v.replaceAll("\\s+"," ").trim();
    }
    static String clip(String str,int n) { if(str==null)return ""; return str.length()>n?str.substring(0,n)+"…":str; }
    static String body(InputStream in, int maxBytes) throws Exception {
        try (InputStream is=in; ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192]; int read; int total=0;
            while ((read=is.read(buf))!=-1) { total+=read; if(total>maxBytes)throw new IllegalStateException("响应体超过扫描限制");out.write(buf,0,read); }
            return out.toString("UTF-8");
        }
    }
    static String cleanError(int status) { return "Quercus HTTP "+status+(status==401?"（Token 无效/过期）":status==403?"（没有访问权限）":""); }
    JSONArray list(String path) throws Exception {
        if (!path.startsWith("/api/v1/")) throw new IllegalArgumentException("Bad API path");
        JSONArray all=new JSONArray(); String next=ORIGIN+path;
        for(int page=0;next!=null && page<60;page++) {
            URL url = new URL(next);trusted(url);
            HttpURLConnection c=(HttpURLConnection)url.openConnection();
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(12000);c.setReadTimeout(16000);
            c.setRequestProperty("Authorization","Bearer "+token);
            c.setRequestProperty("Accept","application/json");
            try {
                int status=c.getResponseCode();if(status!=200)throw new IllegalStateException(cleanError(status));
                JSONArray arr=new JSONArray(body(c.getInputStream(),10*1024*1024));
                for(int i=0;i<arr.length();i++)all.put(arr.get(i));
                String link=c.getHeaderField("Link");next=null;
                if (link!=null) {
                    Matcher m=Pattern.compile("<([^>]+)>;\\s*rel=\"?next\"?").matcher(link);
                    if(m.find()) {URL candidate=new URL(m.group(1));trusted(candidate);next=candidate.toString();}
                }
            } finally {c.disconnect();}
        }
        return all;
    }
    JSONObject object(String path) throws Exception {
        URL url=new URL(ORIGIN+path);trusted(url);
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setInstanceFollowRedirects(false);c.setConnectTimeout(12000);c.setReadTimeout(16000);
        c.setRequestProperty("Authorization","Bearer "+token);
        c.setRequestProperty("Accept","application/json");
        try {int status=c.getResponseCode();if(status!=200)throw new IllegalStateException(cleanError(status));return new JSONObject(body(c.getInputStream(),10*1024*1024));}
        finally {c.disconnect();}
    }
}
